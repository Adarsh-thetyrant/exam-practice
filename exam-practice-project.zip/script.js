
let questions=[];
let current=0;
let answers={};
let review={};

const params=new URLSearchParams(window.location.search);
const test=params.get("test");

fetch(test+"/questions.json")
.then(r=>r.json())
.then(data=>{
questions=data;
createPalette();
loadQuestion();
});

function createPalette(){
let html="";
for(let i=0;i<questions.length;i++){
html+=`<button onclick="gotoQ(${i})" id="q${i}">${i+1}</button>`;
}
document.getElementById("palette").innerHTML=html;
}

function loadQuestion(){
let q=questions[current];
document.getElementById("question").innerHTML=`<img src="${test}/${q.image}" width="600">`;
}

function saveNext(){
let opt=document.querySelector('input[name="opt"]:checked');
if(opt){
answers[current]=opt.value;
document.getElementById("q"+current).classList.add("answered");
}
current++;
if(current<questions.length){loadQuestion();}
}

function markReview(){
review[current]=true;
document.getElementById("q"+current).classList.add("review");
}

function gotoQ(i){
current=i;
loadQuestion();
}

// timer (3 hours)
let time=10800;
setInterval(()=>{
time--;
let h=Math.floor(time/3600);
let m=Math.floor((time%3600)/60);
let s=time%60;
document.getElementById("timer").innerText=h+":"+m+":"+s;
},1000);
